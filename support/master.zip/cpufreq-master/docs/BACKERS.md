---
title: Project's Supporters
permalink: /supporters/
description: Here could be your name, brand, reference and logo.
---

# People donated their **real money**

* #### [Jonathan Alden](https://konkor.github.io/cpufreq/supporters/)
* #### [Manuel Transfeld](https://konkor.github.io/cpufreq/supporters/)
<br>


* **[Joël Dinel](https://konkor.github.io/cpufreq/supporters/)**
* **[Michel Bonifert](https://konkor.github.io/cpufreq/supporters/)**
* **[Patrick Strobel](https://konkor.github.io/cpufreq/supporters/)**
<br><br>


* [Térence Clastres](https://github.com/terencode)
* [Mark Graber](https://konkor.github.io/cpufreq/supporters/)
* [Samir Menon](https://konkor.github.io/cpufreq/supporters/)
* [Idan Bidani](https://konkor.github.io/cpufreq/supporters/)
* [Arnold Schröder](https://konkor.github.io/cpufreq/supporters/)
* [Adam Jones](https://konkor.github.io/cpufreq/supporters/)
* [Alibek Junisbayev](https://konkor.github.io/cpufreq/supporters/)

## [Patreons](https://www.patreon.com/konkor)

* [Nick Krzemienski](https://github.com/krzemienski)
* [Ivan Chayka](https://vk.com/anaumynaugames)
* [Steffen W.](https://www.patreon.com/user/creators?u=7405409)
* [Yoann Deferi](https://konkor.github.io/cpufreq/supporters/)

# People donated their **own time**

## Coding and testing

* [Nailim](https://github.com/Nailim)
* [Gabriel Rauter](https://github.com/raetiacorvus)
* [balsoft](https://github.com/balsoft)
* [Ricardo Rodrigues](https://github.com/RicardoEPRodrigues)
* [Térence Clastres](https://github.com/terencode)
* [Derek W. Stavis](https://github.com/derekstavis)

## Documentation

* [Térence Clastres](https://github.com/terencode)
* [David](https://github.com/BurningSmile)

## Other

* Thanks to all testers and bug reporters.
* Thanks to your feedbacks on network resources.
* Thanks to all media creators mentioned, reviewed and shared it.

# YOUR NAME COULD BE HERE.
## LET'S SUPPORT IT NOW!

* [http://konkor.github.io/cpufreq/donations/](http://konkor.github.io/cpufreq/donations/)
* [http://konkor.github.io/cpufreq/supporters/](http://konkor.github.io/cpufreq/supporters/)
* [http://konkor.github.io/cpufreq/contributors/](http://konkor.github.io/cpufreq/contributors/)
