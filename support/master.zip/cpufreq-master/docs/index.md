---
title: Home
permalink: /
description: Gnome CPU Frequency Monitor and Governor Manager.
layout: home
---
