---
title: Sources and packages
permalink: /sources/
description: Links to the project sources and packages.
---

## Sources and packages

* [GitHub Sources](https://github.com/konkor/cpufreq)
* [Gnome Extensions](https://extensions.gnome.org/extension/1082/cpufreq/)
